SHOW DATABASES;
USE innerglow_db; -- changed from innerglow to innerglow_db
SHOW TABLES;

-- Check table structure
DESCRIBE users;
DESCRIBE appointments;
DESCRIBE screening_results;

SELECT * FROM users;
SELECT * FROM appointments;
SELECT * FROM screening_results;